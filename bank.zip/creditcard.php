<?php
session_start();

// Session check
if (!isset($_SESSION['email'])) {
    header('Location: login.html');
    exit();
}
$timeout = 1800;
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > $timeout) {
    session_unset();
    session_destroy();
    header("Location: login.html");
    exit();
}
$_SESSION['last_activity'] = time();

$email = $_SESSION['email'];

// DB connect
$conn = new mysqli("localhost", "root", "", "bank_system");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch account
$stmt = $conn->prepare("SELECT * FROM accounts WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$account = $stmt->get_result()->fetch_assoc();
$account_number = $account['account_number'];

// Fetch cards linked to this account
$cards = [];
$card_stmt = $conn->prepare("SELECT card_number FROM cards WHERE account_number = ?");
$card_stmt->bind_param("s", $account_number);
$card_stmt->execute();
$card_result = $card_stmt->get_result();
while ($row = $card_result->fetch_assoc()) {
    $cards[] = $row['card_number'];
}

// Handle form
$message = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $card_number = $_POST['card_number'];
    $amount = floatval($_POST['amount']);

    if (in_array($card_number, $cards) && $amount > 0) {
        $used_on = date("Y-m-d H:i:s");
        $insert = $conn->prepare("INSERT INTO card_usage (account_number, card_number, used_on, amount) VALUES (?, ?, ?, ?)");
        $insert->bind_param("sssd", $account_number, $card_number, $used_on, $amount);
        $insert->execute();
        $message = "₹" . number_format($amount, 2) . " used from card $card_number.";
    } else {
        $message = "Invalid card or amount.";
    }
}

// Fetch usage history
$history = [];
$usage_stmt = $conn->prepare("SELECT * FROM card_usage WHERE account_number = ?");
$usage_stmt->bind_param("s", $account_number);
$usage_stmt->execute();
$usage_result = $usage_stmt->get_result();
while ($row = $usage_result->fetch_assoc()) {
    $history[] = $row;
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Card Usage</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial; background: #f4f4f4; }

        .navbar {
            background: #3498db; color: white;
            padding: 15px 30px; display: flex;
            justify-content: space-between; align-items: center;
        }
        .container {
            max-width: 500px; margin: 50px auto; background: white;
            padding: 30px; border-radius: 10px; box-shadow: 0 0 10px #ccc;
        }
        input, select {
            width: 100%; padding: 10px; font-size: 16px; margin-bottom: 20px;
        }
        .back-btn, .apply-btn {
            background: #3498db; color: white;
            padding: 10px; border: none;
            font-size: 16px; width: 100%; border-radius: 5px;
            text-align: center; text-decoration: none;
        }
        .message {
            background: #dff0d8; color: #3c763d;
            padding: 10px; text-align: center; border-radius: 5px;
        }
        ul { margin-top: 15px; padding-left: 20px; }
    </style>
</head>
<body>

<div class="navbar">
    <h2>Welcome, <?php echo htmlspecialchars($account['name']); ?></h2>
    <div>
        <span id="session-timer">Session expires in: 30:00</span>
        <a href="logout.php" style="color:white;">Logout</a>
    </div>
</div>

<div class="container">
    <h2>Card Usage</h2>

    <?php if ($message): ?>
        <div class="message"><?php echo $message; ?></div>
    <?php endif; ?>

    <form method="post">
        <label for="card_number">Select Card:</label>
        <select name="card_number" required>
            <option value="">-- Select Card --</option>
            <?php foreach ($cards as $card): ?>
                <option value="<?php echo $card; ?>"><?php echo chunk_split($card, 4, ' '); ?></option>
            <?php endforeach; ?>
        </select>

        <label for="amount">Amount:</label>
        <input type="number" name="amount" step="0.01" min="1" required>

        <input type="submit" class="apply-btn" value="Submit Transaction"><br>
        <h3>Transaction History</h3>
        <?php if ($history): ?>
            <ul>
                <?php foreach ($history as $row): ?>
                    <li>
                        <?php echo chunk_split($row['card_number'], 4, ' '); ?> - ₹<?php echo number_format($row['amount'], 2); ?> on <?php echo $row['used_on']; ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php else: ?>
            <p>No usage yet.</p>
        <?php endif; ?><br>

        <a class="back-btn" href="dashboard.php">Back to Dashboard</a>
    </form>

    
</div>

<script src="settime.js"></script>
</body>
</html>

<?php
$stmt->close();
$card_stmt->close();
$usage_stmt->close();
$conn->close();
?>
