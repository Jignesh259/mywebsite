<?php
session_start();

// Check if logged in
if (!isset($_SESSION['email'])) {
    header('Location: login.html');
    exit();
}

// Session timeout
$timeout = 1800;
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > $timeout) {
    session_unset();
    session_destroy();
    header("Location: login.html");
    exit();
}
$_SESSION['last_activity'] = time();

$email = $_SESSION['email'];

// Database connection
$local = "localhost";
$user = "root";
$pass = "";
$db = "bank_system";

$conn = new mysqli($local, $user, $pass, $db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get account info
$stmt = $conn->prepare("SELECT * FROM accounts WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
$account = $result->fetch_assoc();
$account_number = $account['account_number'];

// Fetch notifications from the payments table
$notifications_query = "
    SELECT bill_type, amount, payment_date 
    FROM payments 
    WHERE account_number = ? ";  // Limit to 10 most recent notifications

$stmt_notifications = $conn->prepare($notifications_query);
$stmt_notifications->bind_param("s", $account_number);
$stmt_notifications->execute();
$notifications_result = $stmt_notifications->get_result();

// Fetching all notifications
$notifications = [];
while ($row = $notifications_result->fetch_assoc()) {
    $notifications[] = $row;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Notifications</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
        }

        .navbar {
            background-color: #3498db;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 60px;
        }

        .navbar h2 {
            font-size: 22px;
        }

        .navbar a {
            color: white;
            text-decoration: none;
            font-size: 18px;
        }

        .container {
            max-width: 600px;
            margin: 50px auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px #ccc;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .notification {
            border-bottom: 1px solid #eee;
            padding: 15px 0;
        }

        .notification-title {
            font-weight: bold;
            margin-bottom: 5px;
        }

        .notification-date {
            font-size: 12px;
            color: #888;
        }

        .message {
            margin-top: 10px;
        }

        .back-btn {
            display: inline-block;
            margin-top: 20px;
            text-align: center;
            width: 100%;
            background-color: #3498db;
            color: white;
            padding: 10px;
            border-radius: 5px;
            text-decoration: none;
        }
    </style>
</head>
<body>
<header class="navbar">
    <h2>Welcome, <?php echo htmlspecialchars($account['name']); ?></h2>
    <div>
        <span id="session-timer" style="margin-right: 20px;">Session expires in: 30:00</span>
        <a href="logout.php" style="color: white;">Logout</a>
    </div>
</header>

    <div class="container">
        <h2>Your Notifications</h2>

        <?php if (empty($notifications)): ?>
            <p>No new notifications.</p>
        <?php else: ?>
            <?php foreach ($notifications as $notification): ?>
                <div class="notification">
                    <div class="notification-title"><?php echo htmlspecialchars($notification['bill_type']); ?></div>
                    <div class="notification-message"><?php echo htmlspecialchars($notification['amount']); ?></div>
                    <div class="notification-date"><?php echo $notification['payment_date']; ?></div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>

        <a class="back-btn" href="dashboard.php">Back to Dashboard</a>
    </div>

    <script src="settime.js"></script>
</body>
</html>

<?php
// Close database connection
$stmt->close();
$stmt_notifications->close();
$conn->close();
?>
