<?php
session_start();

// Check if logged in
if (!isset($_SESSION['email'])) {
    header('Location: login.html');
    exit();
}

// Session timeout
$timeout = 1800;
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > $timeout) {
    session_unset();
    session_destroy();
    header("Location: login.html");
    exit();
}
$_SESSION['last_activity'] = time();

$email = $_SESSION['email'];

// Database connection
$local = "localhost";
$user = "root";
$pass = "";
$db = "bank_system";

$conn = new mysqli($local, $user, $pass, $db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get account info
$stmt = $conn->prepare("SELECT * FROM accounts WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
$account = $result->fetch_assoc();


$account_number = $account['account_number'];
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $deposit_amount = floatval($_POST['amount']);

    if ($deposit_amount > 0) {
        // Update balance
        $new_balance = $account['balance'] + $deposit_amount;

        $update = $conn->prepare("UPDATE accounts SET balance = ? WHERE email = ?");
        $update->bind_param("ds", $new_balance, $email);
        $update->execute();
        // Log in deposits table
        $deposit_log = $conn->prepare("INSERT INTO deposits (account_number, email, amount) VALUES (?, ?, ?)");
        $deposit_log->bind_param("ssd", $account['account_number'], $email, $deposit_amount);
        $deposit_log->execute();

        // Log in payments table
        $method = "Deposit";
        $status = "Success";
        $payment_date = date('Y-m-d H:i:s');

        $log = $conn->prepare("INSERT INTO payments (account_number, bill_type, consumer_id, amount, payment_method, payment_status, payment_date) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $log->bind_param("sssisss", $account['account_number'], $method, $account['account_number'], $deposit_amount, $method, $status, $payment_date);
        $log->execute();

        $message = "₹" . number_format($deposit_amount, 2) . " successfully deposited!";
        $account['balance'] = $new_balance; // Update local value
    } else {
        $message = "Invalid amount.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Deposit Money</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
        }

        .navbar {
    background-color: #3498db;
    color: white;
    padding: 15px 30px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    height: 60px;
}

.navbar h2 {
    font-size: 22px;
}

.navbar a {
    color: white;
    text-decoration: none;
    font-size: 18px;
}


        .container {
            max-width: 500px;
            margin: 50px auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px #ccc;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        input[type="number"] {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            margin-bottom: 20px;
        }

        input[type="submit"] {
            background: #3498db;
            color: white;
            padding: 10px;
            border: none;
            width: 100%;
            font-size: 16px;
            border-radius: 5px;
        }

        .message {
            background-color: #dff0d8;
            color: #3c763d;
            padding: 10px;
            text-align: center;
            margin-top: 15px;
            border-radius: 5px;
        }

        .back-btn {
            display: inline-block;
            margin-top: 20px;
            text-align: center;
            width: 100%;
            background-color: #3498db;
            color: white;
            padding: 10px;
            border-radius: 5px;
            text-decoration: none;
        }
    </style>
</head>
<body>
<header class="navbar">
    <h2>Welcome, <?php echo htmlspecialchars($account['name']); ?></h2>
    <div>
        <span id="session-timer" style="margin-right: 20px;">Session expires in: 30:00</span>
        <a href="logout.php" style="color: white;">Logout</a>
    </div>
</header>

    <div class="container">
        <h2>Deposit Funds</h2>
        <p><b>Account Number:</b> <?php echo $account['account_number']; ?></p>
        <p><b>Current Balance:</b> ₹<?php echo number_format($account['balance'], 2); ?></p>

        <form method="post">
            <label for="amount"><b>Enter Amount:</b></label>
            <input type="number" name="amount" step="0.01" min="1" required>
            <input type="submit" value="Deposit" class="back-btn"><br>
            <?php if (!empty($message)): ?>
            <div class="message"><?php echo $message; ?></div>
            <?php endif; ?><br>
            <a class="back-btn" href="dashboard.php">Back to Dashboard</a>
        </form>
    </div>
    <script src="settime.js"></script>
</body>
</html>
<?php
$stmt->close();
$conn->close();
?>
