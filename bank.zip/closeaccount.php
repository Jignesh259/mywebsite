<?php
ob_start();
session_start();

// Check if logged in
if (!isset($_SESSION['email'])) {
    header('Location: login.html');
    exit();
}

// Session timeout (30 mins)
$timeout = 1800;
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > $timeout) {
    session_unset();
    session_destroy();
    header("Location: login.html");
    exit();
}
$_SESSION['last_activity'] = time();

$email = $_SESSION['email'];

// DB connection
$local = "localhost";
$user = "root";
$pass = "";
$db = "bank_system";

$conn = new mysqli($local, $user, $pass, $db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get account info
$stmt = $conn->prepare("SELECT * FROM accounts WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
$account = $result->fetch_assoc();

if (!$account) {
    echo "Account not found!";
    exit();
}

$account_number = $account['account_number'];
$name = $account['name'];
$message = "";

// If form submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['confirm']) && $_POST['confirm'] == "yes") {
    // Delete from all related tables
    $tables = ['cards', 'fixed_deposits', 'loan_requests', 'payments', 'recurring_deposits', 'withdrawals'];
    $deletion_success = true;

    foreach ($tables as $table) {
        $del_stmt = $conn->prepare("DELETE FROM $table WHERE account_number = ?");
        if ($del_stmt) {
            $del_stmt->bind_param("s", $account_number);
            if (!$del_stmt->execute()) {
                $deletion_success = false;
                break;
            }
            $del_stmt->close();
        } else {
            $deletion_success = false;
            break;
        }
    }

    // Then delete the main account
    if ($deletion_success) {
        $delete_account_stmt = $conn->prepare("DELETE FROM accounts WHERE account_number = ?");
        $delete_account_stmt->bind_param("s", $account_number);
        $account_deleted = $delete_account_stmt->execute();
        $delete_account_stmt->close();

        if ($account_deleted) {
            session_unset();
            session_destroy();
            // Animation for success
            echo "<script>
                    document.getElementById('status-message').innerHTML = 'Account successfully closed!';
                    document.getElementById('status-message').classList.add('success');
                    setTimeout(function() {
                        window.location.href = 'login.html';
                    }, 3000); // Redirect after 3 seconds
                  </script>";
            exit();
        } else {
            $message = "Failed to delete account.";
        }
    } else {
        $message = "Failed to delete associated account data.";
    }
}

ob_end_flush();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Close Account</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
        }
        .navbar {
            background-color: #3498db;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 60px;
        }
        .navbar h2 {
            font-size: 22px;
        }
        .navbar a {
            color: white;
            text-decoration: none;
            font-size: 18px;
        }
        .container {
            max-width: 500px;
            margin: 50px auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px #ccc;
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        p {
            font-size: 16px;
            margin-bottom: 15px;
            text-align: center;
        }
        form {
            text-align: center;
        }
        .btn {
            padding: 10px 20px;
            font-size: 16px;
            margin: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .confirm {
            background-color: #e74c3c;
            color: white;
        }
        .cancel {
            background-color: #2ecc71;
            color: white;
            text-decoration: none;
        }
        .message {
            text-align: center;
            background-color: #f8d7da;
            color: #721c24;
            padding: 10px;
            margin-top: 15px;
            border-radius: 5px;
        }
        .status-message {
            text-align: center;
            padding: 20px;
            margin-top: 20px;
            font-size: 18px;
            border-radius: 5px;
            opacity: 0;
            transition: opacity 1s ease-in-out;
        }
        .success {
            background-color: #28a745;
            color: white;
            opacity: 1;
        }
        .failure {
            background-color: #dc3545;
            color: white;
            opacity: 1;
        }
    </style>
</head>
<body>

<header class="navbar">
    <h2>Welcome, <?php echo htmlspecialchars($name); ?></h2>
    <div>
        <span id="session-timer" style="margin-right: 20px;">Session expires in: 30:00</span>
        <a href="logout.php">Logout</a>
    </div>
</header>

<div class="container">
    <h2>Close Bank Account</h2>
    <p><strong>Account Number:</strong> <?php echo htmlspecialchars($account_number); ?></p>
    <p>Are you sure you want to permanently close your account?</p>

    <form method="post">
        <input type="hidden" name="confirm" value="yes">
        <button type="submit" class="btn confirm">Yes, Close My Account</button>
        <a href="dashboard.php" class="btn cancel">No, Go Back</a>
    </form>

    <div id="status-message" class="status-message"></div>

    <?php if (!empty($message)) : ?>
        <div class="message"><?php echo $message; ?></div>
    <?php endif; ?>
</div>

<script src="settime.js"></script>
</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
