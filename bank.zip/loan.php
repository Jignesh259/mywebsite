<?php
session_start();

if (!isset($_SESSION['email'])) {
    header('Location: login.html');
    exit();
}

$timeout = 1800;
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > $timeout) {
    session_unset();
    session_destroy();
    header("Location: login.html");
    exit();
}
$_SESSION['last_activity'] = time();

$email = $_SESSION['email'];

$conn = mysqli_connect("localhost", "root", "", "bank_system");
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$query = "SELECT * FROM accounts WHERE email = '$email'";
$result = mysqli_query($conn, $query);
$user = mysqli_fetch_assoc($result);

// Handle loan form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $loan_type = $_POST['loan_type'];
    $amount = $_POST['amount'];
    $duration = $_POST['duration'];

    // In a real system, you'd store this in a "loans" table
    echo "<script>alert('Loan request for ₹$amount ($loan_type, $duration years) submitted successfully.');</script>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Loan Application</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            min-height: 100vh;
        }

        .navbar {
            background-color: #3498db;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 60px;
        }

        .navbar h2 { font-size: 22px; }

        .navbar a {
            color: white;
            text-decoration: none;
            font-size: 18px;
        }

        .container {
            padding: 40px;
            max-width: 700px;
            margin: 40px auto;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }

        h3 {
            margin-bottom: 20px;
            color: #333;
        }

        label {
            display: block;
            margin-top: 15px;
            font-weight: bold;
        }

        input[type="text"], select {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        button {
            margin-top: 20px;
            padding: 12px;
            background-color: #3498db;
            color: white;
            border: none;
            border-radius: 5px;
            width: 100%;
            cursor: pointer;
        }

        button:hover {
            background-color: #2980b9;
        }

        .back-btn {
            display: inline-block;
            background-color: #f1f1f1;
            color: #3498db;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 20px;
            margin-top: 20px;
            text-align: center;
            width: 100%;
        }
    </style>
</head>
<body>

<header class="navbar">
    <h2>Welcome, <?php echo htmlspecialchars($user['name']); ?></h2>
    <div>
        <span id="session-timer" style="margin-right: 20px;">Session expires in: 30:00</span>
        <a href="logout.php">Logout</a>
    </div>
</header>

<div class="container">
    <h3>Loan Application Form</h3>
    <form method="POST" action="loan-done.php">
        <label>Loan Type</label>
        <select name="loan_type" required>
            <option value="">-- Select --</option>
            <option value="Personal">Personal Loan</option>
            <option value="Home">Home Loan</option>
            <option value="Education">Education Loan</option>
            <option value="Vehicle">Vehicle Loan</option>
        </select>

        <label>Amount (₹)</label>
        <input type="text" name="amount" required pattern="\d+" title="Enter a valid amount">

        <label>Duration (Years)</label>
        <input type="text" name="duration" required pattern="\d+" title="Enter number of years">

        <button type="submit">Apply for Loan</button>
    </form>


    <a class="back-btn" href="dashboard.php">← Back to Dashboard</a>
</div>

<script src="settime.js"></script>
</body>
</html>
