<?php
session_start();

// Check if logged in
if (!isset($_SESSION['email'])) {
    header('Location: login.html');
    exit();
}

// Session timeout
$timeout = 1800;
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > $timeout) {
    session_unset();
    session_destroy();
    header("Location: login.html");
    exit();
}
$_SESSION['last_activity'] = time();

$email = $_SESSION['email'];

// DB connection
$conn = new mysqli("localhost", "root", "", "bank_system");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get account details
$stmt = $conn->prepare("SELECT * FROM accounts WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$account = $stmt->get_result()->fetch_assoc();

$account_number = $account['account_number'];
$message = "";

// Handle FD creation
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $amount = floatval($_POST['amount']);
    $months = intval($_POST['duration']);
    $interest_rate = 6.5; // 6.5% fixed for example

    if ($amount > 0 && $months > 0) {
        $start = date('Y-m-d H:i:s');
        $maturity = date('Y-m-d H:i:s', strtotime("+$months months"));

        $insert = $conn->prepare("INSERT INTO fixed_deposits (account_number, amount, duration_months, interest_rate, start_date, maturity_date) VALUES (?, ?, ?, ?, ?, ?)");
        $insert->bind_param("siddss", $account_number, $amount, $months, $interest_rate, $start, $maturity);
        $insert->execute();

        $message = "FD of ₹" . number_format($amount, 2) . " created for $months months at $interest_rate% interest.";
    } else {
        $message = "Enter valid amount and duration.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Fixed Deposit</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial, sans-serif; background: #f4f4f4; }

        .navbar {
            background-color: #3498db;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .container {
            max-width: 600px;
            margin: 50px auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px #ccc;
        }

        h2 { text-align: center; margin-bottom: 20px; }

        input[type="number"] {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            margin-bottom: 20px;
        }

        input[type="submit"] {
            background: #3498db;
            color: white;
            padding: 10px;
            border: none;
            width: 100%;
            font-size: 16px;
            border-radius: 5px;
        }

        .message {
            background-color: #dff0d8;
            color: #3c763d;
            padding: 10px;
            text-align: center;
            margin-top: 15px;
            border-radius: 5px;
        }

        .back-btn {
            display: block;
            margin-top: 20px;
            text-align: center;
            background-color: #3498db;
            color: white;
            padding: 10px;
            border-radius: 5px;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <header class="navbar">
        <h2>Welcome, <?php echo htmlspecialchars($account['name']); ?></h2>
        <div>
            <span id="session-timer">Session expires in: 30:00</span>
            <a href="logout.php" style="color: white;">Logout</a>
        </div>
    </header>

    <div class="container">
        <h2>Create Fixed Deposit</h2>

        <p><b>Account Number:</b> <?php echo $account_number; ?></p>
        <p><b>Current Balance:</b> ₹<?php echo number_format($account['balance'], 2); ?></p>

        <form method="post">
            <label><b>Enter Amount (₹):</b></label>
            <input type="number" name="amount" step="0.01" min="1000" required>

            <label><b>Duration (months):</b></label>
            <input type="number" name="duration" min="1" max="60" required>

            <input type="submit" value="Create FD">
        </form>

        <?php if (!empty($message)): ?>
        <div class="message"><?php echo $message; ?></div>
        <?php endif; ?>

        <a class="back-btn" href="dashboard.php">Back to Dashboard</a>
    </div>

    <script src="settime.js"></script>
</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
