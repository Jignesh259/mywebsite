<?php
require_once('lib/tcpdf/tcpdf.php'); // Adjust path as needed
session_start();

if (!isset($_SESSION['email'])) {
    die("Unauthorized access");
}

$email = $_SESSION['email'];

$host = "localhost";
$user = "root";
$password = "";
$database = "bank_system";

$conn = new mysqli($host, $user, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$accQuery = "SELECT account_number FROM accounts WHERE email = ?";
$stmtAcc = $conn->prepare($accQuery);
$stmtAcc->bind_param("s", $email);
$stmtAcc->execute();
$resultAcc = $stmtAcc->get_result();

if ($resultAcc->num_rows === 0) {
    die("Account not found");
}

$account_number = $resultAcc->fetch_assoc()['account_number'];

// Fetch transactions
$sql = "SELECT * FROM payments WHERE account_number = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $account_number);
$stmt->execute();
$result = $stmt->get_result();

// Create PDF
$pdf = new TCPDF();
$pdf->AddPage();
$pdf->SetFont('dejavusans', '', 10);
$pdf->Write(0, 'Transaction History for ' . $email, '', 0, 'L', true, 0, false, false, 0);

// Table
$html = '
<table border="1" cellpadding="4">
<tr>
    <th><b>ID</b></th>
    <th><b>Bill Type</b></th>
    <th><b>Consumer ID</b></th>
    <th><b>Amount</b></th>
    <th><b>Method</b></th>
    <th><b>Status</b></th>
    <th><b>Date</b></th>
</tr>';

while ($row = $result->fetch_assoc()) {
    $html .= "<tr>
                <td>{$row['id']}</td>
                <td>{$row['bill_type']}</td>
                <td>{$row['consumer_id']}</td>
                <td>₹" . number_format($row['amount'], 2) . "</td>
                <td>{$row['payment_method']}</td>
                <td>{$row['payment_status']}</td>
                <td>{$row['payment_date']}</td>
              </tr>";
}
$html .= '</table>';

$pdf->writeHTML($html, true, false, false, false, '');
$pdf->Output('Transaction_History.pdf', 'D'); // Download
?>
