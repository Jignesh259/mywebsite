<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['email'])) {
    // Redirect to login page if the user is not logged in
    header('Location: login.html');
    exit();
}
// Session timeout limit (30 minutes = 1800 seconds)
// Session timeout limit (30 minutes = 1800 seconds)
$timeout = 1800; // 30*60

if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > $timeout) {
    session_unset();         // Remove session variables
    session_destroy();       // Destroy session
    header("Location: login.html"); // Redirect to login
    exit();
}

$_SESSION['last_activity'] = time(); // Update the session timestamp

// Get the email from the session
$email = $_SESSION['email'];

// Connect to the database
$local = "localhost";
$user = "root";
$pass = "";
$db = "bank_system"; // Change this to your actual DB name

$conn = mysqli_connect($local, $user, $pass, $db);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Fetch user details from the database
$query = "SELECT * FROM accounts WHERE email = '$email'";
$result = mysqli_query($conn, $query);
$user = mysqli_fetch_assoc($result);

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account Details</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            min-height: 100vh;
        }

        .navbar {
            background-color: #3498db;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 60px;
        }

        .navbar h2 {
            font-size: 22px;
        }

        .navbar a {
            color: white;
            text-decoration: none;
            font-size: 18px;
        }

        .container {
            padding: 40px;
            max-width: 900px;
            margin: 0 auto;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .details {
            font-size: 18px;
            margin-bottom: 20px;
        }

        .details b {
            color: #3498db;
        }

        .back-btn {
            display: inline-block;
            background-color: #3498db;
            color:  #f1f1f1;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 20px;
            margin-top: 20px;
            text-align: center;
            width: 100%;
        }

        .back-btn:hover {
            background-color: #2980b9;
        }
    </style>
</head>
<body>

<header class="navbar">
    <h2>Welcome, <?php echo htmlspecialchars($user['name']); ?></h2>
    <div>
        <span id="session-timer" style="margin-right: 20px;">Session expires in: 30:00</span>
        <a href="logout.php" style="color: white;">Logout</a>
    </div>
</header>
<br>

    <!-- Account Details -->
    <div class="container">
        <div class="details">
            <b>Name:</b> <?php echo htmlspecialchars($user['name']); ?><br>
            <b>Email:</b> <?php echo htmlspecialchars($user['email']); ?><br>
            <b>Account Number:</b> <?php echo htmlspecialchars($user['account_number']); ?><br>
            <b>Address:</b> <?php echo htmlspecialchars($user['address']); ?><br>
            <b>Phone Number:</b> <?php echo htmlspecialchars($user['phonenumber']); ?><br>
            <b>Aadhar Card Number:</b> <?php echo htmlspecialchars($user['aadharcard']); ?><br>
            <b>Pan Card Number:</b> <?php echo htmlspecialchars($user['pancard']); ?><br>
            <b>Account Type:</b> <?php echo htmlspecialchars($user['accounttype']); ?><br>
            <b>Account Second Holder Name:</b> <?php echo htmlspecialchars($user['second_person_name']); ?><br>
            <b>Account Balance:</b> <?php echo htmlspecialchars($user['balance']); ?><br>
            <!-- Add more fields here based on what your users' table contains -->
        </div>
        <a href="dashboard.php" class="back-btn">Back to Dashboard</a>
    </div>
    <script src="settime.js"></script>
</body>
</html>
