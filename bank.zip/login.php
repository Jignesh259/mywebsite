<?php
// Start the session
session_start();

// Database connection
$local = "localhost";
$user = "root";
$pass = "";
$db = "bank_system"; // Change this to your actual DB name

$conn = mysqli_connect($local, $user, $pass, $db);

if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

// Get the data from the AJAX request
$email = $_POST['email'];
$password = $_POST['password'];

// Query to check if the email exists in the database
$query = "SELECT * FROM accounts WHERE email = '$email'";
$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) > 0) {
    // If email found, fetch the user data
    $user = mysqli_fetch_assoc($result);

    // Verify password (using password_hash, assuming it was stored using password_hash)
    if (password_verify($password, $user['password'])) {
        // Correct password, store email in session
        $_SESSION['email'] = $email;
        echo "success"; // Return success message
    } else {
        echo "Invalid password."; // Incorrect password
    }
} else {
    echo "Email not found."; // If email not found in DB
}

mysqli_close($conn);
?>
