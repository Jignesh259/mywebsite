<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['email'])) {
    header('Location: login.html');
    exit();
}

$timeout = 1800;
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > $timeout) {
    session_unset();
    session_destroy();
    header("Location: login.html");
    exit();
}

$_SESSION['last_activity'] = time();
$email = $_SESSION['email'];

// DB Connection
$local = "localhost";
$user = "root";
$pass = "";
$db = "bank_system";

$conn = mysqli_connect($local, $user, $pass, $db);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Get user details
$query = "SELECT * FROM accounts WHERE email = ?";
$stmtUser = $conn->prepare($query);
$stmtUser->bind_param("s", $email);
$stmtUser->execute();
$resultUser = $stmtUser->get_result();
$user = $resultUser->fetch_assoc();

// Get transactions
$account_number = $user['account_number'];
$queryTrans = "SELECT * FROM payments WHERE account_number = ?";
$stmtTrans = $conn->prepare($queryTrans);
$stmtTrans->bind_param("s", $account_number);
$stmtTrans->execute();
$resultTrans = $stmtTrans->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Account & Transactions</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding-bottom: 50px;
        }
        .navbar {
            background-color: #3498db;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .container {
            max-width: 1000px;
            margin: 30px auto;
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px #ccc;
        }
        .details, table {
            font-size: 16px;
            margin-bottom: 20px;
        }
        .details b {
            color: #2c3e50;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background-color: #fff;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ddd;
        }
        th {
            background-color: #007BFF;
            color: white;
        }
        button {
            background-color: #3498db;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: #2980b9;
        }
        .back-btn {
            text-decoration: none;
            display: inline-block;
            margin-top: 20px;
            background-color: #3498db;
            color: white;
            padding: 10px 20px;
            border-radius: 20px;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <h2>Welcome, <?php echo htmlspecialchars($user['name']); ?></h2>
        <div>
            <span id="session-timer">Session expires in: 30:00</span>
            <a href="logout.php" style="color:white; margin-left: 20px;">Logout</a>
        </div>
    </div>

    <div class="container" id="pdf-content">
        <h3>Account Holder Details</h3>
        <div class="details">
            <b>Name:</b> <?php echo htmlspecialchars($user['name']); ?><br>
            <b>Email:</b> <?php echo htmlspecialchars($user['email']); ?><br>
            <b>Account Number:</b> <?php echo htmlspecialchars($user['account_number']); ?><br>
            <b>Address:</b> <?php echo htmlspecialchars($user['address']); ?><br>
            <b>Phone Number:</b> <?php echo htmlspecialchars($user['phonenumber']); ?><br>
            <b>Aadhar Card Number:</b> <?php echo htmlspecialchars($user['aadharcard']); ?><br>
            <b>Pan Card Number:</b> <?php echo htmlspecialchars($user['pancard']); ?><br>
            <b>Account Type:</b> <?php echo htmlspecialchars($user['accounttype']); ?><br>
            <b>Second Holder Name:</b> <?php echo htmlspecialchars($user['second_person_name']); ?><br>
            <b>Account Balance:</b> ₹<?php echo number_format($user['balance'], 2); ?><br>
        </div>

        <hr>
        <h3>Transaction History</h3>
        <table id="transactionTable">
            <tr>
                <th>ID</th>
                <th>Bill Type</th>
                <th>Consumer ID</th>
                <th>Amount</th>
                <th>Method</th>
                <th>Status</th>
                <th>Date</th>
            </tr>
            <?php
            if ($resultTrans->num_rows > 0) {
                while ($row = $resultTrans->fetch_assoc()) {
                    echo "<tr>
                            <td>{$row['id']}</td>
                            <td>{$row['bill_type']}</td>
                            <td>{$row['consumer_id']}</td>
                            <td>₹" . number_format($row['amount'], 2) . "</td>
                            <td>{$row['payment_method']}</td>
                            <td>{$row['payment_status']}</td>
                            <td>{$row['payment_date']}</td>
                          </tr>";
                }
            } else {
                echo "<tr><td colspan='7'>No transactions found.</td></tr>";
            }
            ?>
        </table>

        <button onclick="downloadPDF()">Download PDF</button>
        <br><br>
        <a href="dashboard.php" class="back-btn">Back to Dashboard</a>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script>
        async function downloadPDF() {
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF();
            let y = 10;

            doc.setFontSize(16);
            doc.text("Account Holder Details", 10, y);
            y += 10;

            const user = <?php echo json_encode($user); ?>;
            for (const [key, value] of Object.entries(user)) {
                doc.setFontSize(12);
                doc.text(`${key.replace(/_/g, ' ')}: ${value}`, 10, y);
                y += 7;
                if (y > 270) { doc.addPage(); y = 10; }
            }

            y += 10;
            doc.setFontSize(16);
            doc.text("Transaction History", 10, y);
            y += 10;

            const rows = document.querySelectorAll("#transactionTable tr");
            rows.forEach(row => {
                const cols = row.querySelectorAll("td, th");
                let text = Array.from(cols).map(td => td.innerText).join(" | ");
                doc.setFontSize(10);
                doc.text(text, 10, y);
                y += 7;
                if (y > 270) { doc.addPage(); y = 10; }
            });

            doc.save("Bank_Statement.pdf");
        }
    </script>
    <script src="settime.js"></script>
</body>
</html>
<?php
$stmtUser->close();
$stmtTrans->close();
$conn->close();
?>
