<?php
session_start();

// Check if logged in
if (!isset($_SESSION['email'])) {
    header('Location: login.html');
    exit();
}

// Session timeout
$timeout = 1800;
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > $timeout) {
    session_unset();
    session_destroy();
    header("Location: login.html");
    exit();
}
$_SESSION['last_activity'] = time();

$email = $_SESSION['email'];

// Get account info
$local = "localhost";
$user = "root";
$pass = "";
$db = "bank_system";

$conn = new mysqli($local, $user, $pass, $db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$stmt = $conn->prepare("SELECT * FROM accounts WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
$account = $result->fetch_assoc();

$account_number = $account['account_number'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Branch Locator</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
        }

        .navbar {
            background-color: #3498db;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 60px;
        }

        .navbar h2 {
            font-size: 22px;
        }

        .navbar a {
            color: white;
            text-decoration: none;
            font-size: 18px;
        }

        .container {
            max-width: 600px;
            margin: 50px auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px #ccc;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .form-container {
            text-align: center;
        }

        input[type="text"] {
            width: 60%;
            padding: 10px;
            font-size: 16px;
            margin-bottom: 20px;
        }

        input[type="submit"] {
            background: #3498db;
            color: white;
            padding: 10px;
            border: none;
            width: 100%;
            font-size: 16px;
            border-radius: 5px;
        }

        #map {
            height: 400px;
            width: 100%;
            margin-top: 20px;
        }

        .back-btn {
            display: inline-block;
            margin-top: 20px;
            text-align: center;
            width: 100%;
            background-color: #3498db;
            color: white;
            padding: 10px;
            border-radius: 5px;
            text-decoration: none;
        }
    </style>
</head>
<body>

<header class="navbar">
    <h2>Welcome, <?php echo htmlspecialchars($account['name']); ?></h2>
    <div>
        <span id="session-timer" style="margin-right: 20px;">Session expires in: 30:00</span>
        <a href="logout.php" style="color: white;">Logout</a>
    </div>
</header>

<div class="container">
    <h2>Branch Locator</h2>

    <div class="form-container">
        <form method="post" id="branchForm">
            <label for="city"><b>Enter City Name:</b></label>
            <input type="text" name="city" id="city" placeholder="e.g., New York, Mumbai" required>
            <input type="submit" value="Locate Branches">
        </form>
    </div>

    <!-- Map -->
    <div id="map"></div>

    <a class="back-btn" href="dashboard.php">Back to Dashboard</a>
</div>

<script src="https://maps.googleapis.com/maps/api/js?key=YOUR_GOOGLE_API_KEY&callback=initMap" async defer></script>
<script>
// Define some hardcoded bank branch locations (for example)
const branches = {
    "New York": [
        {name: "Bank 1", lat: 40.7128, lng: -74.0060}, // Example coordinates for New York
        {name: "Bank 2", lat: 40.7306, lng: -73.9352}  // Example coordinates for New York
    ],
    "Mumbai": [
        {name: "Bank A", lat: 19.0760, lng: 72.8777},  // Example coordinates for Mumbai
        {name: "Bank B", lat: 19.2183, lng: 72.9784}   // Example coordinates for Mumbai
    ]
};

let map;

function initMap() {
    // Set the default center for the map
    const defaultCenter = { lat: 40.7128, lng: -74.0060 }; // Default: New York
    map = new google.maps.Map(document.getElementById("map"), {
        zoom: 10,
        center: defaultCenter
    });
}

document.getElementById("branchForm").addEventListener("submit", function(event) {
    event.preventDefault();

    const city = document.getElementById("city").value.trim();
    
    // Check if city exists in our hardcoded data
    if (branches[city]) {
        // Clear any existing markers
        const existingMarkers = map.markers || [];
        existingMarkers.forEach(marker => marker.setMap(null));
        
        // Set new center based on city input
        const cityBranches = branches[city];
        const newCenter = cityBranches[0]; // Set the center to the first branch
        map.setCenter(new google.maps.LatLng(newCenter.lat, newCenter.lng));
        map.setZoom(12);

        // Place markers for each branch
        cityBranches.forEach(function(branch) {
            const marker = new google.maps.Marker({
                position: { lat: branch.lat, lng: branch.lng },
                map: map,
                title: branch.name
            });

            // Store markers in map object to clear later
            map.markers = map.markers || [];
            map.markers.push(marker);
        });
    } else {
        alert("No branches found for this city.");
    }
});
</script>
<script src="settime.js"></script>
</body>
</html>
