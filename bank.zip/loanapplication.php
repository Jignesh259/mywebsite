<?php
// same session/account logic
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $loan_type = $_POST['loan_type'];
    $amount = floatval($_POST['amount']);
    $duration = intval($_POST['duration']);
    if ($amount > 0 && $duration > 0) {
        $stmt = $conn->prepare("INSERT INTO loans (account_number, loan_type, amount, duration_months, apply_date, status) VALUES (?, ?, ?, ?, NOW(), 'Pending')");
        $stmt->bind_param("ssdi", $account['account_number'], $loan_type, $amount, $duration);
        $stmt->execute();
        $message = "Loan application submitted for ₹" . number_format($amount, 2);
    } else {
        $message = "Invalid input.";
    }
}
?>

<?php include 'layout_header.php'; ?>
<div class="container">
    <h2>Loan Application</h2>
    <form method="post">
        <label>Loan Type:</label>
        <input type="text" name="loan_type" required>
        <label>Amount:</label>
        <input type="number" name="amount" step="0.01" min="1000" required>
        <label>Duration (Months):</label>
        <input type="number" name="duration" min="1" required>
        <input type="submit" value="Apply Loan">
    </form>
    <?php if ($message): ?><div class="message"><?= $message ?></div><?php endif; ?>
    <a class="back-btn" href="dashboard.php">Back to Dashboard</a>
</div>
<script src="settime.js"></script>
</body></html>
