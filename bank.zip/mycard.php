<?php
session_start();

// Session timeout limit (30 minutes)
$timeout = 1800;

if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > $timeout) {
    session_unset();
    session_destroy();
    header("Location: login.html");
    exit();
}
$_SESSION['last_activity'] = time();

// Check login
if (!isset($_SESSION['email'])) {
    header('Location: login.html');
    exit();
}

$email = $_SESSION['email'];
$local = "localhost";
$user = "root";
$pass = "";
$db = "bank_system";

$conn = mysqli_connect($local, $user, $pass, $db);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Assuming card details are stored in a table named `cards` linked by email
$query = "SELECT accounts.name, cards.card_number, cards.card_type, cards.expiry_date, cards.card_holder_name FROM accounts 
          JOIN cards ON accounts.email = cards.email 
          WHERE accounts.email = '$email'";

$result = mysqli_query($conn, $query);
$card = mysqli_fetch_assoc($result);

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Card</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        * {
            margin: 0; padding: 0; box-sizing: border-box;
        }
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            min-height: 100vh;
        }
        .navbar {
            background-color: #3498db;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 60px;
        }
        .navbar h2 {
            font-size: 22px;
        }
        .navbar a {
            color: white;
            text-decoration: none;
            font-size: 18px;
        }
        .container {
            padding: 40px;
            max-width: 900px;
            margin: 0 auto;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .details {
            font-size: 18px;
            margin-bottom: 20px;
        }
        .details b {
            color: #3498db;
        }
        .back-btn {
            display: inline-block;
            background-color: #3498db;
            color:  #f1f1f1;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 20px;
            margin-top: 20px;
            text-align: center;
            width: 100%;
        }
        .back-btn:hover {
            background-color: #2980b9;
        }
    </style>
</head>
<body>
<header class="navbar">
    <h2>Welcome, <?php echo htmlspecialchars($card['name']); ?></h2>
    <div>
        <span id="session-timer" style="margin-right: 20px;">Session expires in: 30:00</span>
        <a href="logout.php">Logout</a>
    </div>
</header>

<br>

<div class="container">
    <div class="details">
        <?php if ($card): ?>
            <b>Card Number:</b> **** **** **** <?php echo htmlspecialchars(substr($card['card_number'], -4)); ?><br>
            <b>Card Type:</b> <?php echo htmlspecialchars($card['card_type']); ?><br>
            <b>Expiry Date:</b> <?php echo htmlspecialchars($card['expiry_date']); ?><br>
            <b>Card Holder Name:</b> <?php echo htmlspecialchars($card['card_holder_name']); ?><br>
        <?php else: ?>
            <p>No card details found for this account.</p>
        <?php endif; ?>
    </div>
    <a href="dashboard.php" class="back-btn">Back to Dashboard</a>
</div>

<script src="settime.js"></script>
</body>
</html>
