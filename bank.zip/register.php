<?php
// Set correct timezone
date_default_timezone_set('Asia/Kolkata');

// Collect POST data securely
$name = $_POST['name'];
$phonenumber = $_POST['phonenumber'];
$aadharcard = $_POST['aadharcard'];
$pancard = $_POST['pancard'];
$address = $_POST['address'];
$email = $_POST['email'];
$accounttype = $_POST['accounttype'];
$secondpersonname = $_POST['second_person_name'];
$card = $_POST['card'];
$password = password_hash($_POST['password'], PASSWORD_DEFAULT);
$account_number = $_POST['account_number'];

// Database connection
$conn = mysqli_connect("localhost", "root", "", "bank_system");
if (!$conn) {
    echo "Database not connected";
    exit;
}

// Check if account number exists
$checkQuery = "SELECT * FROM accounts WHERE account_number = '$account_number'";
$checkResult = mysqli_query($conn, $checkQuery);
if (mysqli_num_rows($checkResult) > 0) {
    echo "Account number already exists. Please refresh and try again.";
    mysqli_close($conn);
    exit;
}

// Insert into accounts table
$insertquery = "INSERT INTO accounts (
    name, phonenumber, aadharcard, pancard, address, email, accounttype,
    second_person_name, account_number, balance, password
) VALUES (
    '$name', '$phonenumber', '$aadharcard', '$pancard', '$address', '$email',
    '$accounttype', '$secondpersonname', '$account_number', 0.00, '$password'
)";
$run = mysqli_query($conn, $insertquery);
if (!$run) {
    echo "Data not inserted: " . mysqli_error($conn);
    mysqli_close($conn);
    exit;
}

// Function to generate card details
function generateCardDetails() {
    $card_number = strval(random_int(4000000000000000, 4999999999999999));
    $cvv = strval(random_int(100, 999));
    $expiry = date('m/y', strtotime('+5 years')); // ✅ expiry set here
    return [$card_number, $cvv, $expiry];
}

// Determine card types
$cards = [];
if ($card === "Debit" || $card === "Credit") {
    $cards[] = $card;
} elseif ($card === "Credit,Debit" || $card === "Both") {
    $cards = ["Debit", "Credit"];
}

// Insert card(s)
foreach ($cards as $type) {
    list($card_number, $cvv, $expiry) = generateCardDetails();
    $bank_name = "SBI";

    $card_query = "INSERT INTO cards (
        account_number, email, card_type, card_number, card_holder_name,
        expiry_date, cvv, bank_name, issue_date
    ) VALUES (
        '$account_number', '$email', '$type', '$card_number', '$name',
        '$expiry', '$cvv', '$bank_name', CURDATE()
    )";

    mysqli_query($conn, $card_query);
}

echo "success";
mysqli_close($conn);
?>
