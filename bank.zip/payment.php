<?php
session_start();

// Session timeout limit (30 minutes = 1800 seconds)
$timeout = 1800; // 30*60

if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > $timeout) {
    session_unset();         // Remove session variables
    session_destroy();       // Destroy session
    header("Location: login.html"); // Redirect to login
    exit();
}

$_SESSION['last_activity'] = time(); // Update the session timestamp

// Check if the user is logged in
if (!isset($_SESSION['email'])) {
    header('Location: login.html');
    exit();
}

$email = $_SESSION['email'];
$host = "localhost";
$user = "root";
$pass = "";
$db = "bank_system";

$conn = mysqli_connect($host, $user, $pass, $db);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Fetch user name from the database
$query = "SELECT name FROM accounts WHERE email = '$email'";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($result);
$name = $row['name'];
$query = "SELECT account_number FROM accounts WHERE email = '$email'";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($result);
$account_number = $row['account_number'];


mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Page</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        * {
            margin: 0; padding: 0; box-sizing: border-box;
        }
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            min-height: 100vh;
        }
        .navbar {
            background-color: #3498db;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 60px;
        }
        .navbar h2 { font-size: 22px; }
        .navbar a {
            color: white;
            text-decoration: none;
            font-size: 18px;
        }
        .payment-container {
            max-width: 800px;
            margin: 40px auto;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            padding: 30px;
        }
        .payment-container h3 {
            font-size: 24px;
            margin-bottom: 20px;
        }
        .payment-container label {
            font-size: 18px;
            margin-bottom: 10px;
            display: block;
        }
        .payment-container input, .payment-container select {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            margin-bottom: 20px;
            border-radius: 5px;
            border: 1px solid #ddd;
        }
        .payment-btn {
            background-color: #3498db;
            color: white;
            padding: 10px 20px;
            font-size: 18px;
            border-radius: 20px;
            border: none;
            cursor: pointer;
            width: 100%;
        }
        .payment-btn:hover {
            background-color: #2980b9;
        }
        .back-btn {
            display: inline-block;
            background-color: #f1f1f1;
            color: #3498db;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 20px;
            margin-top: 20px;
            text-align: center;
            width: 100%;
        }
        .back-btn:hover {
            background-color: #ecf0f1;
        }

        /* Animation for payment processing */
        .loading {
            display: none;
            text-align: center;
            padding: 20px;
            font-size: 18px;
            color: #3498db;
        }
        .spinner {
            border: 4px solid #f3f3f3;
            border-top: 4px solid #3498db;
            border-radius: 50%;
            width: 50px;
            height: 50px;
            animation: spin 1s linear infinite;
            margin: 20px auto;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
</head>
<body>

<header class="navbar">
    <h2>Welcome, <?php echo htmlspecialchars($name); ?></h2>
    <div>
        <span id="session-timer" style="margin-right: 20px;">Session expires in: 30:00</span>
        <a href="logout.php">Logout</a>
    </div>
</header>

<div class="payment-container">
    <h3>Make a Payment for This Account:- <?php echo htmlspecialchars($account_number); ?> </h3>
    <form id="payment-form" action="payment-success.php" method="POST" onsubmit="startPaymentProcess(event)">
    <label for="bill_type">Bill Type</label>
    <select id="bill_type" name="bill_type" required>
        <option value="">-- Select Bill Type --</option>
        <option value="mobile_recharge">Mobile Recharge</option>
        <option value="electricity">Electricity Bill</option>
        <option value="gas">Gas Bill</option>
        <option value="water">Water Bill</option>
        <option value="internet">Internet Bill</option>
    </select>

    <label for="consumer_id">Consumer / Account Number</label>
    <input type="text" id="consumer_id" name="consumer_id" required placeholder="Enter account or consumer number">

    <label for="amount">Amount</label>
    <input type="number" id="amount" name="amount" required placeholder="Enter amount to pay">

    <label for="payment_method">Payment Method</label>
    <select id="payment_method" name="payment_method" required>
        <option value="credit_card">Credit Card</option>
        <option value="debit_card">Debit Card</option>
        <option value="bank_transfer">Bank Transfer</option>
    </select>

    <button type="submit" class="payment-btn">Pay Now</button>
</form>


    <!-- Loading animation -->
    <div id="loading" class="loading">
        <div class="spinner"></div>
        <p>Processing your payment...</p>
    </div>

    <a href="dashboard.php" class="back-btn">Back to Dashboard</a>
</div>

<!-- Link the external JavaScript file -->
<script src="settime.js"></script>

<script>
// JavaScript to handle the payment animation and redirection
function startPaymentProcess(event) {
    event.preventDefault();

    document.getElementById('loading').style.display = 'block';

    setTimeout(function() {
        document.getElementById('payment-form').submit(); // Submit the form to process_payment.php
    }, 2000);
}

</script>

</body>
</html>
