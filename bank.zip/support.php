<?php
session_start();

// Session check
if (!isset($_SESSION['email'])) {
    header('Location: login.html');
    exit();
}

// Session timeout
$timeout = 1800;
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > $timeout) {
    session_unset();
    session_destroy();
    header("Location: login.html");
    exit();
}
$_SESSION['last_activity'] = time();

$email = $_SESSION['email'];

// Database
$conn = new mysqli("localhost", "root", "", "bank_system");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch user info
$stmt = $conn->prepare("SELECT * FROM accounts WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
$account = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Support Chat</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial, sans-serif; background: #f4f4f4; }

        .navbar {
            background-color: #3498db;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 60px;
        }

        .navbar h2 {
            font-size: 22px;
        }

        .navbar a {
            color: white;
            text-decoration: none;
            font-size: 18px;
        }

        .container {
            max-width: 600px;
            margin: 50px auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px #ccc;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .chatbox {
            height: 400px;
            border: 1px solid #ccc;
            border-radius: 8px;
            padding: 15px;
            overflow-y: auto;
            background: #f9f9f9;
            margin-bottom: 20px;
        }

        .chat-msg {
            margin: 10px 0;
            padding: 10px;
            border-radius: 8px;
            max-width: 80%;
        }

        .user-msg {
            background: #3498db;
            color: white;
            align-self: flex-end;
            margin-left: auto;
        }

        .ai-msg {
            background: #eee;
            color: black;
            align-self: flex-start;
        }

        .chat-input {
            display: flex;
        }

        .chat-input input {
            flex: 1;
            padding: 10px;
            font-size: 16px;
        }

        .chat-input button {
            background-color: #3498db;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
        }

        .back-btn {
            display: inline-block;
            margin-top: 20px;
            width: 100%;
            background-color: #3498db;
            color: white;
            padding: 10px;
            border-radius: 5px;
            text-align: center;
            text-decoration: none;
        }
    </style>
</head>
<body>

<header class="navbar">
    <h2>Welcome, <?php echo htmlspecialchars($account['name']); ?></h2>
    <div>
        <span id="session-timer" style="margin-right: 20px;">Session expires in: 30:00</span>
        <a href="logout.php">Logout</a>
    </div>
</header>

<div class="container">
    <h2>Support Chat (AI Assistant)</h2>
    <div class="chatbox" id="chatbox">
        <div class="chat-msg ai-msg">Hello! How can I assist you today?</div>
    </div>

    <div class="chat-input">
        <input type="text" id="userInput" placeholder="Type your question here...">
        <button onclick="sendMessage()">Send</button>
    </div>

    <a class="back-btn" href="dashboard.php">Back to Dashboard</a>
</div>

<script src="settime.js"></script>
<script>
function sendMessage() {
    const input = document.getElementById('userInput');
    const message = input.value.trim();
    if (message === "") return;

    const chatbox = document.getElementById('chatbox');

    // Append user message
    const userMsg = document.createElement('div');
    userMsg.className = 'chat-msg user-msg';
    userMsg.textContent = message;
    chatbox.appendChild(userMsg);
    chatbox.scrollTop = chatbox.scrollHeight;

    // Fetch response from chat_api.php
    fetch('chat_api.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: message })
    })
    .then(response => response.json())
    .then(data => {
        const aiMsg = document.createElement('div');
        aiMsg.className = 'chat-msg ai-msg';
        aiMsg.textContent = data.reply || "No response from AI.";
        chatbox.appendChild(aiMsg);
        chatbox.scrollTop = chatbox.scrollHeight;
    })
    .catch(error => {
        const aiMsg = document.createElement('div');
        aiMsg.className = 'chat-msg ai-msg';
        aiMsg.textContent = "Error: Could not contact AI server.";
        chatbox.appendChild(aiMsg);
    });

    input.value = "";
}
</script>


</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
