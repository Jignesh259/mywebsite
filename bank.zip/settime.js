
// Check if there's any existing countdown saved in sessionStorage
let remainingTime = parseInt(sessionStorage.getItem('remainingTime')) || 1800; // Default to 30 minutes if not set

// Function to update the countdown timer
function updateTimer() {
    const minutes = String(Math.floor(remainingTime / 60)).padStart(2, '0');
    const seconds = String(remainingTime % 60).padStart(2, '0');
    document.getElementById('session-timer').textContent = `Session expires in: ${minutes}:${seconds}`;

    if (remainingTime <= 0) {
        alert("Session expired. Redirecting to login page.");
        window.location.href = "logout.php"; // Redirect to logout
    } else {
        remainingTime--;
        sessionStorage.setItem('remainingTime', remainingTime); // Save the remaining time to sessionStorage
        setTimeout(updateTimer, 1000); // Update the timer every second
    }
}

// Start the timer
updateTimer();
