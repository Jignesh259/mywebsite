<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['email'])) {
    header('Location: login.html');
    exit();
}

// Session timeout logic
$timeout = 1800;
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > $timeout) {
    session_unset();
    session_destroy();
    header("Location: login.html");
    exit();
}
$_SESSION['last_activity'] = time();

$email = $_SESSION['email'];

// DB Connection
$conn = mysqli_connect("localhost", "root", "", "bank_system");
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Update if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $phonenumber = $_POST['phonenumber'];
    $address = $_POST['address'];
    $second_person_name = $_POST['second_person_name'];

    $updateQuery = "UPDATE accounts SET 
        name = '$name',
        phonenumber = '$phonenumber',
        address = '$address',
        second_person_name = '$second_person_name'
        WHERE email = '$email'";

    if (mysqli_query($conn, $updateQuery)) {
        echo "<script>alert('Details updated successfully.'); window.location.href='update.php';</script>";
        exit();
    } else {
        echo "Update failed: " . mysqli_error($conn);
    }
}

// Fetch user details
$query = "SELECT * FROM accounts WHERE email = '$email'";
$result = mysqli_query($conn, $query);
$user = mysqli_fetch_assoc($result);
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Update Account Details</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial, sans-serif; background-color: #f4f4f4; min-height: 100vh; }

        .navbar {
            background-color: #3498db;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 60px;
        }

        .navbar h2 {
            font-size: 22px;
        }

        .navbar a {
            color: white;
            text-decoration: none;
            font-size: 18px;
        }

        .container {
            max-width: 600px;
            margin: 40px auto;
            background: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h2 { text-align: center; color: #333; }

        label {
            display: block;
            margin-top: 15px;
            font-weight: bold;
        }

        input[type="text"] {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        button {
            margin-top: 20px;
            padding: 12px 20px;
            background: #3498db;
            color: #fff;
            border: none;
            border-radius: 20px;
            cursor: pointer;
            width: 100%;
        }
        .back-btn {
            display: inline-block;
            background-color: #f1f1f1;
            color: #3498db;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 20px;
            margin-top: 20px;
            text-align: center;
            width: 100%;
        }

        button:hover {
            background: #2980b9;
        }

        a.back {
            display: block;
            margin-top: 20px;
            text-align: center;
            color: #3498db;
            text-decoration: none;
        }
    </style>
</head>
<body>

<header class="navbar">
    <h2>Welcome, <?php echo htmlspecialchars($user['name']); ?></h2>
    <div>
        <span id="session-timer" style="margin-right: 20px;">Session expires in: 30:00</span>
        <a href="logout.php" style="color: white;">Logout</a>
    </div>
</header>

<div class="container">
    <h2>Update Your Details</h2>
    <form method="POST" action="">
        <label>Name</label>
        <input type="text" name="name" value="<?php echo htmlspecialchars($user['name']); ?>" required>

        <label>Phone Number</label>
        <input type="text" name="phonenumber" value="<?php echo htmlspecialchars($user['phonenumber']); ?>" required>

        <label>Address</label>
        <input type="text" name="address" value="<?php echo htmlspecialchars($user['address']); ?>" required>

        <label>Second Holder Name</label>
        <input type="text" name="second_person_name" value="<?php echo htmlspecialchars($user['second_person_name']); ?>">

        <button type="submit">Update</button>
    </form>
    <a href="dashboard.php" class="back-btn">← Back to Dashboard</a>
</div>

<script src="settime.js"></script>
</body>
</html>
