<?php
session_start();

// Check login
if (!isset($_SESSION['email'])) {
    header('Location: login.html');
    exit();
}

// Session timeout
$timeout = 1800;
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > $timeout) {
    session_unset();
    session_destroy();
    header("Location: login.html");
    exit();
}
$_SESSION['last_activity'] = time();

$email = $_SESSION['email'];

// DB connection
$conn = new mysqli("localhost", "root", "", "bank_system");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get account info
$stmt = $conn->prepare("SELECT * FROM accounts WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
$account = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Your Profile</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial, sans-serif; background: #f4f4f4; }

        .navbar {
            background-color: #3498db;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 60px;
        }

        .navbar h2 {
            font-size: 22px;
        }

        .navbar a {
            color: white;
            text-decoration: none;
            font-size: 18px;
        }

        .container {
            max-width: 600px;
            margin: 50px auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px #ccc;
        }

        h2 { text-align: center; margin-bottom: 20px; }

        .info {
            margin-bottom: 10px;
            font-size: 16px;
        }

        .info b {
            display: inline-block;
            width: 180px;
        }

        .back-btn {
            display: inline-block;
            margin-top: 30px;
            text-align: center;
            width: 100%;
            background-color: #3498db;
            color: white;
            padding: 10px;
            border-radius: 5px;
            text-decoration: none;
        }
    </style>
</head>
<body>

<header class="navbar">
    <h2>Welcome, <?php echo htmlspecialchars($account['name']); ?></h2>
    <div>
        <span id="session-timer" style="margin-right: 20px;">Session expires in: 30:00</span>
        <a href="logout.php" style="color: white;">Logout</a>
    </div>
</header>

<div class="container">
    <h2>Your Profile Details</h2>

    <div class="info"><b>Full Name:</b> <?php echo htmlspecialchars($account['name']); ?></div>
    <div class="info"><b>Email:</b> <?php echo htmlspecialchars($account['email']); ?></div>
    <div class="info"><b>Account Number:</b> <?php echo htmlspecialchars($account['account_number']); ?></div>
    <div class="info"><b>Phone Number:</b> <?php echo htmlspecialchars($account['phonenumber']); ?></div>
    <div class="info"><b>Address:</b> <?php echo htmlspecialchars($account['address']); ?></div>
    <div class="info"><b>Second Holder Name:</b> <?php echo htmlspecialchars($account['second_person_name']); ?></div>
    <div class="info"><b>Account Balance:</b> ₹<?php echo number_format($account['balance'], 2); ?></div>
    <div class="info"><b>Account Type:</b> <?php echo htmlspecialchars($account['accounttype']); ?></div>

    <a class="back-btn" href="dashboard.php">← Back to Dashboard</a>
</div>

<script src="settime.js"></script>
</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
