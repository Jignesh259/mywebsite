<?php
session_start();

// Session timeout limit (30 minutes = 1800 seconds)
$timeout = 1800;

if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > $timeout) {
    session_unset();
    session_destroy();
    header("Location: login.html");
    exit();
}

$_SESSION['last_activity'] = time();

if (!isset($_SESSION['email'])) {
    header('Location: login.html');
    exit();
}

$email = $_SESSION['email'];
$host = "localhost";
$user = "root";
$pass = "";
$db = "bank_system";

$conn = mysqli_connect($host, $user, $pass, $db);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Fetch user name, account number, and balance
$query = "SELECT name, account_number, balance FROM accounts WHERE email = ?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "s", $email);
mysqli_stmt_execute($stmt);
mysqli_stmt_bind_result($stmt, $name, $account_number, $balance);
mysqli_stmt_fetch($stmt);
mysqli_stmt_close($stmt);

$payment_successful = false;
$insufficient_balance = false;

// Handle POST form data
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $bill_type = $_POST['bill_type'];
    $consumer_id = $_POST['consumer_id'];
    $amount = floatval($_POST['amount']);
    $payment_method = $_POST['payment_method'];
    $payment_status = "Completed";

    if ($amount > $balance) {
        $insufficient_balance = true;
    } else {
        // Deduct the amount
        $new_balance = $balance - $amount;
        $update_sql = "UPDATE accounts SET balance = ? WHERE email = ?";
        $update_stmt = mysqli_prepare($conn, $update_sql);
        mysqli_stmt_bind_param($update_stmt, "ds", $new_balance, $email);
        mysqli_stmt_execute($update_stmt);
        mysqli_stmt_close($update_stmt);

        // Insert into payment history
        $insert_sql = "INSERT INTO payments (account_number, bill_type, consumer_id, amount, payment_method, payment_status) 
                       VALUES (?, ?, ?, ?, ?, ?)";
        $insert_stmt = mysqli_prepare($conn, $insert_sql);
        mysqli_stmt_bind_param($insert_stmt, "issdss", $account_number, $bill_type, $consumer_id, $amount, $payment_method, $payment_status);
        mysqli_stmt_execute($insert_stmt);
        mysqli_stmt_close($insert_stmt);

        $payment_successful = true;
    }
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Result</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        * {
            margin: 0; padding: 0; box-sizing: border-box;
        }
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .payment-success-container {
            max-width: 600px;
            background-color: white;
            border-radius: 10px;
            padding: 40px;
            text-align: center;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .payment-success-container h2 {
            color: #3498db;
            font-size: 32px;
            margin-bottom: 20px;
        }
        .payment-success-container p {
            font-size: 18px;
            color: #555;
            margin-bottom: 40px;
        }
        .payment-success-container .success-icon {
            font-size: 60px;
            color: #2ecc71;
            margin-bottom: 20px;
        }
        .payment-success-container .fail-icon {
            font-size: 60px;
            color: #e74c3c;
            margin-bottom: 20px;
        }
        .payment-success-container a {
            display: inline-block;
            padding: 12px 24px;
            font-size: 18px;
            text-decoration: none;
            background-color: #3498db;
            color: white;
            border-radius: 5px;
            margin-top: 20px;
        }
        .payment-success-container a:hover {
            background-color: #2980b9;
        }
    </style>
</head>
<body>

<div class="payment-success-container">
    <?php if ($payment_successful): ?>
        <div class="success-icon"><i class="fa fa-check-circle"></i></div>
        <h2>Payment Successful!</h2>
        <p>Thank you, <?php echo htmlspecialchars($name); ?>. Your payment has been processed.</p>
    <?php elseif ($insufficient_balance): ?>
        <div class="fail-icon"><i class="fa fa-times-circle"></i></div>
        <h2>Payment Failed</h2>
        <p>Sorry, you do not have enough balance to complete this transaction.</p>
    <?php else: ?>
        <div class="fail-icon"><i class="fa fa-times-circle"></i></div>
        <h2>Payment Error</h2>
        <p>An error occurred. Please try again.</p>
    <?php endif; ?>

    <a href="dashboard.php">Back to Dashboard</a>
</div>

</body>
</html>
