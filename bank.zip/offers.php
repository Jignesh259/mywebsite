<?php
session_start();

// Session check
if (!isset($_SESSION['email'])) {
    header('Location: login.html');
    exit();
}

$timeout = 1800;
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > $timeout) {
    session_unset();
    session_destroy();
    header("Location: login.html");
    exit();
}
$_SESSION['last_activity'] = time();

$email = $_SESSION['email'];

// Database connection
$conn = new mysqli("localhost", "root", "", "bank_system");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch account info
$stmt = $conn->prepare("SELECT * FROM accounts WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$account = $stmt->get_result()->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Special Offers</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial, sans-serif; background: #f4f4f4; }

        .navbar {
            background-color: #3498db;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .container {
            max-width: 700px;
            margin: 50px auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px #ccc;
        }

        h2 { text-align: center; margin-bottom: 20px; }

        .offer {
            background: #ecf9ff;
            border-left: 5px solid #3498db;
            padding: 15px;
            margin-bottom: 15px;
            border-radius: 5px;
        }

        .back-btn {
            display: block;
            text-align: center;
            background-color: #3498db;
            color: white;
            padding: 10px;
            border-radius: 5px;
            text-decoration: none;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <header class="navbar">
        <h2>Welcome, <?php echo htmlspecialchars($account['name']); ?></h2>
        <div>
            <span id="session-timer">Session expires in: 30:00</span>
            <a href="logout.php" style="color: white;">Logout</a>
        </div>
    </header>

    <div class="container">
        <h2>Special Offers</h2>

        <div class="offer">
            <h3>✨ Get 5% Cashback</h3>
            <p>Use your credit card for purchases above ₹5000 and get 5% cashback.</p>
        </div>

        <div class="offer">
            <h3>📱 Mobile Recharge Offer</h3>
            <p>Recharge through our portal and get 10% bonus balance instantly!</p>
        </div>

        <div class="offer">
            <h3>💳 Free Credit Card Upgrade</h3>
            <p>Upgrade to Platinum card for free this month with 2X reward points.</p>
        </div>

        <div class="offer">
            <h3>🏦 Fixed Deposit Bonus</h3>
            <p>Create a new FD and get 0.5% extra interest for 1 year or more!</p>
        </div>

        <a class="back-btn" href="dashboard.php">Back to Dashboard</a>
    </div>

    <script src="settime.js"></script>
</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
