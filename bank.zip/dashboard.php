<?php
session_start();

// Session timeout limit in seconds (30 minutes)
$timeout = 1800; // 30*60

// Check for session timeout
// Session timeout limit (30 minutes = 1800 seconds)
$timeout = 1800; // 30*60

if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > $timeout) {
    session_unset();         // Remove session variables
    session_destroy();       // Destroy session
    header("Location: login.html"); // Redirect to login
    exit();
}

$_SESSION['last_activity'] = time(); // Update the session timestamp


// Check if the user is logged in
if (!isset($_SESSION['email'])) {
    header('Location: login.html');
    exit();
}

$email = $_SESSION['email'];
$host = "localhost";
$user = "root";
$pass = "";
$db = "bank_system";

$conn = mysqli_connect($host, $user, $pass, $db);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$query = "SELECT name FROM accounts WHERE email = '$email'";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($result);
$name = $row['name'];

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        * {
            margin: 0; padding: 0; box-sizing: border-box;
        }
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            min-height: 100vh;
        }
        .navbar {
            background-color: #3498db;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 60px;
        }
        .navbar h2 { font-size: 22px; }
        .navbar a {
            color: white;
            text-decoration: none;
            font-size: 18px;
        }
        .card-container {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            padding: 40px;
            max-width: 1200px;
            margin: 0 auto;
        }
        .card {
            background-color: #3498db;
            border-radius: 10px;
            padding: 30px 10px;
            text-align: center;
            color: white;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
        }
        .card:hover {
            background-color: #2980b9;
            transform: translateY(-5px);
            cursor: pointer;
        }
        .card .icon {
            font-size: 40px;
            margin-bottom: 15px;
            color: white;
        }
        .card .title {
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 15px;
        }
        .card .card-btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: white;
            color: #3498db;
            border-radius: 20px;
            font-size: 14px;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }
        .card .card-btn:hover {
            background-color: #ecf0f1;
        }
    </style>
</head>
<body>
<header class="navbar">
    <h2>Welcome, <?php echo htmlspecialchars($name); ?></h2>
        <div>
            <span id="session-timer" style="margin-right: 20px;">Session expires in: 30:00</span>
            <a href="logout.php">Logout</a>
        </div>
    </header>
    <div class="card-container">
        <div class="card"><i class="fas fa-user icon"></i><div class="title">Account Details</div><a href="detail.php" class="card-btn">View</a></div>
        <div class="card"><i class="fas fa-money-check-alt icon"></i><div class="title">Payment</div><a href="payment.php" class="card-btn">Pay Now</a></div>
        <div class="card"><i class="fas fa-id-card icon"></i><div class="title">My Card</div><a href="mycard.php" class="card-btn">Show Card</a></div>
        <div class="card"><i class="fas fa-edit icon"></i><div class="title">Update Details</div><a href="update.php" class="card-btn">Edit</a></div>
        <div class="card"><i class="fas fa-university icon"></i><div class="title">Loan Details</div><a href="loan.php" class="card-btn">View</a></div>
        <div class="card"><i class="fas fa-history icon"></i><div class="title">Transaction History</div><a href="transaction.php" class="card-btn">Check</a></div>
        <div class="card"><i class="fas fa-piggy-bank icon"></i><div class="title">Deposit Money</div><a href="deposit.php" class="card-btn">Deposit</a></div>
        <div class="card"><i class="fas fa-hand-holding-usd icon"></i><div class="title">Withdraw Money</div><a href="withdraw.php" class="card-btn">Withdraw</a></div>
        <div class="card"><i class="fas fa-user-cog icon"></i><div class="title">Profile Settings</div><a href="profile.php" class="card-btn">Manage</a></div>
        <div class="card"><i class="fas fa-bell icon"></i><div class="title">Notifications</div><a href="notifications.php" class="card-btn">Check</a></div>
        <div class="card"><i class="fas fa-headset icon"></i><div class="title">Support</div><a href="support.php" class="card-btn">Contact</a></div>
        <div class="card"><i class="fas fa-cog icon"></i><div class="title">Settings</div><a href="settings.php" class="card-btn">Edit</a></div>
        <div class="card"><i class="fas fa-credit-card icon"></i><div class="title">Card</div><a href="creditcard.php" class="card-btn">Details</a></div>
        <div class="card"><i class="fas fa-gift icon"></i><div class="title">Offers & Rewards</div><a href="offers.php" class="card-btn">Explore</a></div>
        <div class="card"><i class="fas fa-coins icon"></i><div class="title">Fixed Deposit</div><a href="fixeddeposit.php" class="card-btn">Open</a></div>
        <div class="card"><i class="fas fa-coins icon"></i><div class="title">Recurring Deposit</div><a href="recurringdeposit.php" class="card-btn">Open</a></div>
        <div class="card"><i class="fas fa-exchange-alt icon"></i><div class="title">Fund Transfer</div><a href="fundtransfer.php" class="card-btn">Transfer</a></div>
        <div class="card"><i class="fas fa-file-invoice-dollar icon"></i><div class="title">Bill Payment</div><a href="billpayment.php" class="card-btn">Pay</a></div>
        <div class="card"><i class="fas fa-chart-line icon"></i><div class="title">Investment</div><a href="investment.php" class="card-btn">View</a></div>
        <div class="card"><i class="fas fa-calculator icon"></i><div class="title">EMI Calculator</div><a href="emi.php" class="card-btn">Calculate</a></div>
        <div class="card"><i class="fas fa-map-marker-alt icon"></i><div class="title">Branch Locator</div><a href="branchlocator.php" class="card-btn">Find</a></div>
        <div class="card"><i class="fas fa-id-badge icon"></i><div class="title">KYC Documents</div><a href="kystore.php" class="card-btn">Upload</a></div>
        <div class="card"><i class="fas fa-door-closed icon"></i><div class="title">Close Account</div><a href="closeaccount.php" class="card-btn">Request</a></div>
    </div>
    <script src="settime.js"></script>

</body>
</html>
