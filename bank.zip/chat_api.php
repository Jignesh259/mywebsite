<?php
header('Content-Type: application/json');

// Read message from frontend
$data = json_decode(file_get_contents("php://input"), true);
$userMessage = trim($data['message'] ?? '');

if (empty($userMessage)) {
    echo json_encode(['reply' => 'Message cannot be empty.']);
    exit;
}

// Set your OpenAI API key
$apiKey = 'sk-XXXXXXXXXXXXXXXXXXXXXXXXXXXX';  // Replace with your key

$payload = [
    'model' => 'gpt-3.5-turbo',
    'messages' => [
        ['role' => 'system', 'content' => 'You are a helpful AI banking assistant.'],
        ['role' => 'user', 'content' => $userMessage],
    ]
];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.openai.com/v1/chat/completions');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Authorization: Bearer ' . $apiKey,
]);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));

$response = curl_exec($ch);
$err = curl_error($ch);
curl_close($ch);

if ($err) {
    echo json_encode(['reply' => 'AI Error: ' . $err]);
} else {
    $result = json_decode($response, true);
    $reply = $result['choices'][0]['message']['content'] ?? 'No reply';
    echo json_encode(['reply' => $reply]);
}
?>
