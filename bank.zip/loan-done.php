<?php
session_start();

if (!isset($_SESSION['email'])) {
    header('Location: login.html');
    exit();
}

$timeout = 1800;
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > $timeout) {
    session_unset();
    session_destroy();
    header("Location: login.html");
    exit();
}
$_SESSION['last_activity'] = time();

$email = $_SESSION['email'];
$conn = mysqli_connect("localhost", "root", "", "bank_system");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$query = "SELECT * FROM accounts WHERE email = '$email'";
$result = mysqli_query($conn, $query);
$user = mysqli_fetch_assoc($result);

// Initialize loan request status
$loan_applied = false;
$loan_error = false;

// Handle loan form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $loan_type = $_POST['loan_type'];
    $amount = $_POST['amount'];
    $duration = $_POST['duration'];

    // Check if the user already has an active or pending loan
    $check_loan_sql = "SELECT COUNT(*) FROM loan_requests WHERE account_number = ? AND status IN ('Pending', 'Approved')";
    $check_loan_stmt = mysqli_prepare($conn, $check_loan_sql);
    mysqli_stmt_bind_param($check_loan_stmt, "s", $user['account_number']);
    mysqli_stmt_execute($check_loan_stmt);
    mysqli_stmt_bind_result($check_loan_stmt, $loan_exists);
    mysqli_stmt_fetch($check_loan_stmt);
    mysqli_stmt_close($check_loan_stmt);

    if ($loan_exists > 0) {
        $loan_error = true;
    } else {
        // Insert loan request
        $insert_loan_sql = "INSERT INTO loan_requests (account_number, email, loan_type, amount, duration_years, status) 
                            VALUES (?, ?, ?, ?, ?, 'Pending')";
        $insert_loan_stmt = mysqli_prepare($conn, $insert_loan_sql);
        mysqli_stmt_bind_param($insert_loan_stmt, "ssssi", $user['account_number'], $email, $loan_type, $amount, $duration);
        mysqli_stmt_execute($insert_loan_stmt);
        mysqli_stmt_close($insert_loan_stmt);

        $loan_applied = true;
    }
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Loan Application Result</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            min-height: 100vh;
        }

        .container {
            padding: 40px;
            max-width: 700px;
            margin: 40px auto;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            text-align: center;
        }

        h2 { color: #3498db; font-size: 32px; }
        p { font-size: 18px; margin-top: 20px; color: #555; }
        .success { color: #2ecc71; }
        .error { color: #e74c3c; }

        .back-btn {
            display: inline-block;
            background-color: #f1f1f1;
            color: #3498db;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            margin-top: 20px;
            text-align: center;
            width: 100%;
        }
    </style>
</head>
<body>

<div class="container">
    <?php if ($loan_applied): ?>
        <h2 class="success">Loan Request Submitted</h2>
        <p>Your loan request for ₹<?php echo htmlspecialchars($amount); ?> (<?php echo htmlspecialchars($loan_type); ?>, <?php echo htmlspecialchars($duration); ?> years) has been successfully submitted. It will be processed shortly.</p>
    <?php elseif ($loan_error): ?>
        <h2 class="error">Loan Request Denied</h2>
        <p>You already have a pending or approved loan request. Please repay or wait for processing before applying again.</p>
    <?php else: ?>
        <h2 class="error">Loan Request Error</h2>
        <p>An error occurred while processing your loan request. Please try again later.</p>
    <?php endif; ?>

    <a class="back-btn" href="dashboard.php">Back to Dashboard</a>
</div>

</body>
</html>
