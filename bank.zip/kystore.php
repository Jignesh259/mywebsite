<?php
session_start();

// Check if logged in
if (!isset($_SESSION['email'])) {
    header('Location: login.html');
    exit();
}

// Session timeout
$timeout = 1800;
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > $timeout) {
    session_unset();
    session_destroy();
    header("Location: login.html");
    exit();
}
$_SESSION['last_activity'] = time();

$email = $_SESSION['email'];

// Database connection
$local = "localhost";
$user = "root";
$pass = "";
$db = "bank_system";

$conn = new mysqli($local, $user, $pass, $db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get account info based on logged-in user's email
$stmt = $conn->prepare("SELECT * FROM accounts WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
$account = $result->fetch_assoc();

// Check if account exists for the logged-in user
if (!$account) {
    echo "Account not found!";
    exit();
}

$account_number = $account['account_number'];  // Fetching account number
$account_balance = $account['balance']; // Assuming there's a balance field
$account_name = $account['name']; // Assuming there's a name field
$account_email = $account['email']; // Email for the user
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Bank Store - Products & Services</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
        }

        .navbar {
            background-color: #3498db;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 60px;
        }

        .navbar h2 {
            font-size: 22px;
        }

        .navbar a {
            color: white;
            text-decoration: none;
            font-size: 18px;
        }

        .container {
            max-width: 800px;
            margin: 50px auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px #ccc;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .product-list {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
        }

        .product-card {
            background: #fff;
            border: 1px solid #ddd;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px #ddd;
        }

        .product-card h3 {
            font-size: 18px;
            margin-bottom: 10px;
        }

        .product-card p {
            font-size: 14px;
            color: #555;
        }

        .product-card .price {
            font-size: 16px;
            color: #3498db;
            font-weight: bold;
        }

        .account-info {
            margin-bottom: 30px;
            padding: 20px;
            background-color: #f9f9f9;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .account-info p {
            font-size: 16px;
            margin-bottom: 10px;
        }

        .back-btn {
            display: inline-block;
            margin-top: 20px;
            text-align: center;
            width: 100%;
            background-color: #3498db;
            color: white;
            padding: 10px;
            border-radius: 5px;
            text-decoration: none;
        }
    </style>
</head>
<body>

<header class="navbar">
    <h2>Welcome, <?php echo htmlspecialchars($account['name']); ?></h2>
    <div>
        <span id="session-timer" style="margin-right: 20px;">Session expires in: 30:00</span>
        <a href="logout.php" style="color: white;">Logout</a>
    </div>
</header>

<div class="container">
    <h2>Bank Products & Services</h2>

    <!-- Display Account Information -->
    <div class="account-info">
        <h3>Your Account Information</h3>
        <p><strong>Account Number:</strong> <?php echo htmlspecialchars($account_number); ?></p>
        <p><strong>Name:</strong> <?php echo htmlspecialchars($account_name); ?></p>
        <p><strong>Email:</strong> <?php echo htmlspecialchars($account_email); ?></p>
        <p><strong>Account Balance:</strong> ₹<?php echo number_format($account_balance, 2); ?></p>
    </div>
    <a class="back-btn" href="dashboard.php">Back to Dashboard</a>
</div>

<script src="settime.js"></script>

</body>
</html>

<?php
$conn->close();
?>
